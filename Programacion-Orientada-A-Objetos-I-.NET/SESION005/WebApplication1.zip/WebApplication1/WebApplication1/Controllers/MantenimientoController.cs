﻿using Microsoft.AspNetCore.Mvc;
using NuGet.Configuration;
using WebApplication1.Models;



namespace WebApplication1.Controllers
{
    public class MantenimientoController : Controller
    {

        private static List<Cliente> lclientes = new List<Cliente>()
        {
            new Cliente{DNI = "77559988", Nombre = "Juan", Direccion ="Chorrillos", Celular = "996688549", Email = "juanpe@gmail.com"},
            new Cliente{DNI = "66554433", Nombre = "María", Direccion = "Miraflores", Celular = "987654321", Email = "maria@gmail.com"},
            new Cliente{DNI = "55443322", Nombre = "Carlos", Direccion = "San Isidro", Celular = "912345678", Email = "carlos@gmail.com"},
            new Cliente{DNI = "44332211", Nombre = "Ana", Direccion = "Barranco", Celular = "923456789", Email = "ana@gmail.com"},
            new Cliente{DNI = "33221100", Nombre = "Luis", Direccion = "Surco", Celular = "934567890", Email = "luis@gmail.com"},
            new Cliente{DNI = "22110099", Nombre = "Elena", Direccion = "La Molina", Celular = "945678901", Email = "elena@gmail.com"}
        };

        public async Task<IActionResult> Index(string dato)
        {
            // Variable temporal de tipo List<Cliente>
            List<Cliente> temporal;

            // Verificar si el parámetro 'dato' está vacío o es nulo
            if (string.IsNullOrEmpty(dato))
            {
                // Si 'dato' está vacío o es nulo, retornar toda la lista de clientes
                return View(await Task.Run(() => lclientes)); // Retornamos toda la lista de clientes con await
            }
            else // Caso contrario, si 'dato' contiene información, se hace la búsqueda de ese dato
            {
                // Filtrar la lista de clientes donde el nombre contiene el valor de 'dato' (ignorando mayúsculas/minúsculas)
                temporal = lclientes.Where(
                    c => c.Nombre.Contains(dato, StringComparison.CurrentCultureIgnoreCase)).ToList();

                // Retornar la lista filtrada de clientes
                return View(await Task.Run(() => temporal));
            }
        }



        //METODO CREATE
        public async Task<IActionResult> Create()
        {
            return View(await Task.Run(() => new Cliente() ) );
        }

        [HttpPost]
        public async Task<IActionResult> Create(Cliente cli)
        {

            if (ModelState.IsValid)
            {
                lclientes.Add(cli); 
                ViewBag.mensaje = "Registro realizado";
                return View( await Task.Run( () => lclientes   )   ); //await para ejecutar de manera asincrónica
            }

            return View(await Task.Run( () => cli ) ); // await para ejecutar de manera asincrónica
        }


        //METODO DETAILS 
        public async Task<IActionResult> Details(string dni)
        {
            var clienteExiste = lclientes.FirstOrDefault(clie => clie.DNI == dni);

            if (clienteExiste == null)
            {
                return NotFound();
            }

            return View( await Task.Run( () =>  clienteExiste ) );
        }


        //METODO EDIT 
        public async Task<IActionResult> Edit(string  dni)
        {

            var clienteExiste = lclientes.FirstOrDefault(cli => cli.DNI == dni );

            if (clienteExiste == null)
            {
                return NotFound();
            }

            return View(await Task.Run( () => clienteExiste )  );
        }


        [HttpPost]
        public async Task<IActionResult> Edit(Cliente client)
        {
            if (ModelState.IsValid)
            {
                var clienteExiste = lclientes.FirstOrDefault(cli => cli.DNI == client.DNI);

                if (clienteExiste == null)
                {
                    return await Task.Run( () =>  NotFound()   ) ;
                }

                //actualizar datos
                clienteExiste.DNI = client.DNI;
                clienteExiste.Nombre = client.Nombre;
                clienteExiste.Direccion = client.Direccion;
                clienteExiste.Celular = client.Celular;
                clienteExiste.Direccion = client.Direccion;

                return RedirectToAction( await Task.Run ( () => "index" ) );
            }
            return View(await Task.Run ( () =>  client ) );
        }


        //METODO DELETE
        public async Task<IActionResult> Delete(string dni)
        {
            var clienteExiste = lclientes.FirstOrDefault(cli => cli.DNI == dni);

            if(clienteExiste == null)
            {
                return NotFound();
            }

            return View(await Task.Run(() => clienteExiste));
        }


        [HttpPost]
        public async Task<IActionResult> Delete(string dni,Cliente c)
        {
            var clienteExiste = lclientes.FirstOrDefault(cli => cli.DNI == dni);

            if(clienteExiste == null)
            {
                return NotFound();
            }

            lclientes.Remove(clienteExiste);
            return RedirectToAction("Index"  );
        }


    }
}
