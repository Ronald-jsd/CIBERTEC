﻿namespace WebApplication1.Models
{
    public class Cliente
    {
        public string DNI {  get; set; }
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string Celular { get; set; }
        public string Email { get; set; }
 

    }
}
