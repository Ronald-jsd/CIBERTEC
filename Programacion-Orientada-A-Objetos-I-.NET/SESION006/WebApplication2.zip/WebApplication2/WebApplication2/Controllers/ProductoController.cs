﻿using Microsoft.AspNetCore.Mvc;

using WebApplication2.Models; //improtar las clases model
using Newtonsoft.Json; //importar el paquete nuget


namespace WebApplication2.Controllers
{
    public class ProductoController : Controller
    {

        //Creacion de dos objetos 
        static string jProducto = @"
        [
            {
                'IDProducto' :1,
                'Descripcion':'Laptop',
                'Presentacion': 'Caja',
                'Precio':1500,
                'Stock':50
            },
            {
                'IDProducto' :2,
                'Descripcion':'Impresora',
                'Presentacion': 'Caja',
                'Precio':600,
                'Stock':30
            },
            {
                'IDProducto' :3,
                'Descripcion':'Mouse',
                'Presentacion': 'Blister',
                'Precio':25,
                'Stock':200
            },
            {
                'IDProducto' :4,
                'Descripcion':'Teclado',
                'Presentacion': 'Caja',
                'Precio':45,
                'Stock':150
            },
            {
                'IDProducto' :5,
                'Descripcion':'Monitor',
                'Presentacion': 'Caja',
                'Precio':300,
                'Stock':80
            },
            {
                'IDProducto' :6,
                'Descripcion':'Disco Duro Externo',
                'Presentacion': 'Caja',
                'Precio':100,
                'Stock':60
            }
        ]";


        public IActionResult Index(string texto)
        {

            List<Producto> listaProductos = new List<Producto>();


            if (!string.IsNullOrEmpty(jProducto))
            {
                listaProductos = JsonConvert.DeserializeObject<List<Producto>>(jProducto);//deserializo el json 
            }
            if (string.IsNullOrEmpty(texto))
            {
                return View(listaProductos);
            }

            var productosFiltrados =  listaProductos.Where(p => p.Descripcion.Contains(texto, StringComparison.CurrentCultureIgnoreCase)).ToList() ;
            return View(productosFiltrados);
        }

        public IActionResult Create()
        {
            return View(new Producto());
        }

        [HttpPost]
        public IActionResult Create(Producto p) 
        {
            string mensaje = "";
            try
            {
                List<Producto> listaProductos = JsonConvert.DeserializeObject<List<Producto>>(jProducto); // //deserializo Json a una lista de productos
                listaProductos.Add(p); //agrego el objeto a la lista 
                jProducto = JsonConvert.SerializeObject(listaProductos);//serializo de nuevo el objeto  a json
                mensaje = "Producto registrado";
            }
            catch (JsonException e)//json exception
            {
                mensaje = e.Message;
            }
            ViewBag.mensaje = mensaje;
            return View(p);
        }
        //Estan ingresando los datos como objetos pero no como json
        //Si queremos que ingrese a nuestro json
        //Debemos convertir nuestro objeto a una lista
        //esa lista agregamos a nuestra lista que ya tenekos mas arriba
        //una vez la lista este agregada procedemos a serializar para que quede almacenada un json con 3 objetos 


        public IActionResult Details(int id)
        {
            //nuestros datos se encuentran en json y para mostrar en la vista
            //deserializamos el json para mostrar
            List<Producto> listaProductos = JsonConvert.DeserializeObject<List<Producto>>(jProducto);
            Producto pro = listaProductos.FirstOrDefault( p => p.IDProducto == id );
            return View(pro);

        }


        public IActionResult Edit(int id)
        {
            List<Producto> listaProductos = JsonConvert.DeserializeObject<List<Producto>>(jProducto); // //deserializo Json a una lista de productos
            var productoExiste = listaProductos.FirstOrDefault(p => p.IDProducto == id);
            if (productoExiste == null) 
            { 
               return NotFound();
            }

            return View(productoExiste);
        }

        [HttpPost]
        public IActionResult Edit(Producto pro) 
        {
            if (ModelState.IsValid)
            {
                List<Producto> listaProductos = JsonConvert.DeserializeObject<List<Producto>>(jProducto); // //deserializo Json a una lista de productos
                var productoExiste = listaProductos.FirstOrDefault(p => p.IDProducto == pro.IDProducto);
                if (productoExiste == null) 
                {
                    return NotFound();
                }
                //actualizo los datos
                productoExiste.IDProducto = pro.IDProducto;
                productoExiste.Precio = pro.Precio;
                productoExiste.Descripcion = pro.Descripcion;
                productoExiste.Presentacion = pro.Presentacion;
                productoExiste.Stock = pro.Stock;
                //serializar la lista a json 
                jProducto = JsonConvert.SerializeObject(listaProductos);//serializo de nuevo el objeto  a json para guardar los datos/*
                                                                        //Convierte la lista actualizada de vuelta a JSON para que jProducto contenga los datos actualizados.*/
                return RedirectToAction("Index");
            }
            return View(pro);
        }


        public IActionResult Delete(int id)
        {
            List<Producto> lProductos = JsonConvert.DeserializeObject<List<Producto>>(jProducto);
            var productosExistentes = lProductos.FirstOrDefault(p => p.IDProducto == id);
            if (productosExistentes == null)
            {
                return NotFound();
            }
            return  View(productosExistentes);
        }


        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmado(int id)
        {
            List<Producto> lProductos = JsonConvert.DeserializeObject<List<Producto>>(jProducto);
            var productosExistentes = lProductos.FirstOrDefault(p => p.IDProducto == id );
            if (productosExistentes == null)
            {
                return NotFound();
            }
            lProductos.Remove(productosExistentes);
            jProducto = JsonConvert.SerializeObject(lProductos);
            return RedirectToAction("Index");
        }






    }
}
